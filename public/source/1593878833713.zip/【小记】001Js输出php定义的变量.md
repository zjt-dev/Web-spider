 <span style="color: #0000ff;">var</span> data = <?php echo json\_encode($value) ?><span style="color: #000000;">
　　console.log(JSON.parse(data))
</span>