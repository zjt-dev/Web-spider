html,body{min-height};  无效  
无效的原因应该就是没有对比元素，解决方法：  
html{ height:100%;  
} body{ min-height:100% }