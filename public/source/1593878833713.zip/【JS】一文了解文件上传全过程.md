## [#](https://qiufeng.blue/node/upload.html#%E5%89%8D%E8%A8%80)前言

平常在写业务的时候常常会用的到的是 `GET`, `POST`请求去请求接口，`GET` 相关的接口会比较容易基本不会出错，而对于 `POST`中常用的 表单提交，`JSON`提交也比较容易，但是对于文件上传呢？大家可能对这个步骤会比较害怕，因为可能大家对它并不是怎么熟悉，而浏览器`Network`对它也没有详细的进行记录，因此它成为了我们心中的一根刺，我们老是无法确定，关于文件上传到底是我写的有问题呢？还是后端有问题，当然，我们一般都比较谦虚， 总是会在自己身上找原因，可是往往实事呢？可能就出在后端身上，可能是他接受写的有问题，导致你换了各种请求库去尝试，`axios`，`request`，`fetch` 等等。那么我们如何避免这种情况呢？我们自身要对这一块够熟悉，才能不以猜的方式去写代码。如果你觉得我以上说的你有同感，那么你阅读完这篇文章你将收获自信，你将不会质疑自己，不会以猜的方式去写代码。

本文比较长可能需要花点时间去看，需要有耐心，我采用自顶向下的方式，所有示例会先展现出你熟悉的方式，再一层层往下, 先从请求端是怎么发送文件的，再到接收端是怎么解析文件的。以下是讲解的大纲，我们先从浏览器端上传文件，再到服务端上传文件，然后我们再来解析文件是如何被解析的。

## [#](https://qiufeng.blue/node/upload.html#%E5%89%8D%E7%BD%AE%E7%9F%A5%E8%AF%86)前置知识

## [#](https://qiufeng.blue/node/upload.html#%E4%BB%80%E4%B9%88%E6%98%AF-multipart-form-data)什么是 multipart/form-data?

`multipart/form-data` 最初由 [《RFC 1867: Form-based File Upload in HTML》](https://www.ietf.org/rfc/rfc1867.txt)文档提出。

> Since file-upload is a feature that will benefit many applications, this proposes an extension to HTML to allow information providers to express file upload requests uniformly, and a MIME compatible representation for file upload responses.

由于文件上传功能将使许多应用程序受益，因此建议对HTML进行扩展，以允许信息提供者统一表达文件上传请求，并提供文件上传响应的MIME兼容表示。

总结就是原先的规范不满足啦，我要扩充规范了。

## [#](https://qiufeng.blue/node/upload.html#%E6%96%87%E4%BB%B6%E4%B8%8A%E4%BC%A0%E4%B8%BA%E4%BB%80%E4%B9%88%E8%A6%81%E7%94%A8-multipart-form-data%EF%BC%9F)文件上传为什么要用 multipart/form-data？

> The encoding type application/x-www-form-urlencoded is inefficient for sending large quantities of binary data or text containing non-ASCII characters. Thus, a new media type,multipart/form-data, is proposed as a way of efficiently sending the values associated with a filled-out form from client to server.

1867文档中也写了为什么要新增一个类型，而不使用旧有的`application/x-www-form-urlencoded`：因为此类型不适合用于传输大型二进制数据或者包含非ASCII字符的数据。平常我们使用这个类型都是把表单数据使用url编码后传送给后端，二进制文件当然没办法一起编码进去了。所以`multipart/form-data`就诞生了，专门用于有效的传输文件。

也许你有疑问？那可以用 `application/json`吗?

其实我认为，无论你用什么都可以传，只不过会要综合考虑一些因素的话，`multipart/form-data`更好。例如我们知道了文件是以二进制的形式存在，`application/json` 是以文本形式进行传输，那么某种意义上我们确实可以将文件转成例如文本形式的 `Base64` 形式。但是呢，你转成这样的形式，后端也需要按照你这样传输的形式，做特殊的解析。并且文本在传输过程中是相比二进制效率低的，那么对于我们动辄几十M几百M的文件来说是速度是更慢的。

以上为什么文件传输要用`multipart/form-data` 我还可以举个例子，例如你在中国，你想要去美洲，我们的`multipart/form-data`相当于是选择飞机，而`application/json`相当于高铁，但是呢？中国和美洲之间没有高铁啊，你执意要坐高铁去，你可以花昂贵的代价（后端额外解析你的文本）造高铁去美洲，但是你有更加廉价的方式坐飞机（使用`multipart/form-data`）去美洲（去传输文件）。你图啥？（如果你有钱有时间，抱歉，打扰了，老子给你道歉）

## [#](https://qiufeng.blue/node/upload.html#multipart-form-data%E8%A7%84%E8%8C%83%E6%98%AF%E4%BB%80%E4%B9%88%EF%BC%9F)multipart/form-data规范是什么？

摘自 [《RFC 1867: Form-based File Upload in HTML》](https://www.ietf.org/rfc/rfc1867.txt) 6.Example

```
Content-type: multipart/form-data, boundary=AaB03x

--AaB03x
content-disposition: form-data; name="field1"
Joe Blow
--AaB03x
content-disposition: form-data; name="pics"; filename="file1.txt"
Content-Type: text/plain

... contents of file1.txt ...
--AaB03x--
```

可以简单解释一些，首先是请求类型，然后是一个 boundary （分割符），这个东西是干啥的呢？其实看名字就知道，分隔符，当时分割作用，因为可能有多文件多字段，每个字段文件之间，我们无法准确地去判断这个文件哪里到哪里为截止状态。因此需要有分隔符来进行划分。然后再接下来就是声明内容的描述是 form-data 类型，字段名字是啥，如果是文件的话，得知道文件名是啥，还有这个文件的类型是啥，这个也很好理解，我上传一个文件，我总得告诉后端，我传的是个啥，是图片？还是一个txt文本？这些信息肯定得告诉人家，别人才好去进行判断，后面我们也会讲到如果这些没有声明的时候，会发生什么？

好了讲完了这些前置知识，我们接下来要进入我们的主题了。面对File, formData,Blob,Base64,ArrayBuffer,到底怎么做？还有文件上传不仅仅是前端的事。服务端也可以文件上传（例如我们利用某云，把静态资源上传到 OSS 对象存储）。服务端和客户端也有各种类型，Buffer，Stream，Base64....头秃，怎么搞？不急，就是因为上传文件不单单是前端的事，所以我将以下上传文件的一方称为请求端，接受文件一方称为接收方。我会以请求端各种上传方式，接收端是怎么解析我们的文件以及我们最终的杀手锏调试工具-wireshark来进行讲解。

![file-upload](https://s3.qiufengh.com/blog/file-upload.png)

## [#](https://qiufeng.blue/node/upload.html#%E8%AF%B7%E6%B1%82%E7%AB%AF)请求端

## [#](https://qiufeng.blue/node/upload.html#%E6%B5%8F%E8%A7%88%E7%AB%AF)浏览端

## [#](https://qiufeng.blue/node/upload.html#file)File

首先我们先写下最简单的一个表单提交方式。

```

```

我们选择文件后上传，发现后端返回了文件不存在。

![image-20200328191433694](https://s3.qiufengh.com/blog/image-20200328191433694.png)

不用着急，熟悉的同学可能立马知道是啥原因了。嘘，知道了也听我慢慢叨叨。

我们打开控制台，由于表单提交会进行网页跳转，因此我们勾选`preserve log` 来进行日志追踪。

![image-20200328191807526](https://s3.qiufengh.com/blog/image-20200328191807526.png)

![image-20200328191733536](https://s3.qiufengh.com/blog/image-20200328191733536.png)

我们可以发现其实 `FormData` 中 `file` 字段显示的是文件名，并没有将真正的内容进行传输。再看请求头。

![image-20200328192020599](https://s3.qiufengh.com/blog/image-20200328192020599.png)

发现是请求头和预期不符，也印证了 `application/x-www-form-urlencoded` 无法进行文件上传。

我们加上请求头，再次请求。

```
action="http://localhost:7787/files" enctype="multipart/form-data" method="POST">
  name="file" type="file" id="file">
  type="submit" value="提交">
>
```

![image-20200328192539734](https://s3.qiufengh.com/blog/image-20200328192539734.png)

发现文件上传成功，简单的表单上传就是像以上一样简单。但是你得熟记文件上传的格式以及类型。

## [#](https://qiufeng.blue/node/upload.html#formdata)FormData

formData 的方式我随便写了以下几种方式。

```
type="file" id="file">
id="submit">上传>
src<span class="token attr-value"><span class="token punctuation">=<span class="token punctuation">"https://cdn.bootcss.com/axios/0.19.2/axios.min.js<span class="token punctuation">"<span class="token punctuation">><span class="token script"><span class="token tag"><span class="token tag"><span class="token punctuation"></script<span class="token punctuation">>
<span class="token tag"><span class="token tag"><span class="token punctuation"><script<span class="token punctuation">><span class="token script"><span class="token language-javascript">
submit<span class="token punctuation">.<span class="token function-variable function">onclick <span class="token operator">= <span class="token punctuation">(<span class="token punctuation">) <span class="token operator">=> <span class="token punctuation">{
    <span class="token keyword">const file <span class="token operator">= document<span class="token punctuation">.<span class="token function">getElementById<span class="token punctuation">(<span class="token string">'file'<span class="token punctuation">)<span class="token punctuation">.files<span class="token punctuation">[<span class="token number">0<span class="token punctuation">]<span class="token punctuation">;
    <span class="token keyword">var form <span class="token operator">= <span class="token keyword">new <span class="token class-name">FormData<span class="token punctuation">(<span class="token punctuation">)<span class="token punctuation">;
    form<span class="token punctuation">.<span class="token function">append<span class="token punctuation">(<span class="token string">'file'<span class="token punctuation">, file<span class="token punctuation">)<span class="token punctuation">;
  
  	<span class="token comment">// type 1
    axios<span class="token punctuation">.<span class="token function">post<span class="token punctuation">(<span class="token string">'http://localhost:7787/files'<span class="token punctuation">, form<span class="token punctuation">)<span class="token punctuation">.<span class="token function">then<span class="token punctuation">(<span class="token parameter">res <span class="token operator">=> <span class="token punctuation">{
        console<span class="token punctuation">.<span class="token function">log<span class="token punctuation">(res<span class="token punctuation">.data<span class="token punctuation">)<span class="token punctuation">;
    <span class="token punctuation">}<span class="token punctuation">)
  	<span class="token comment">// type 2
  	<span class="token function">fetch<span class="token punctuation">(<span class="token string">'http://localhost:7787/files'<span class="token punctuation">, <span class="token punctuation">{
        method<span class="token operator">: <span class="token string">'POST'<span class="token punctuation">,
        body<span class="token operator">: form
    <span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">.<span class="token function">then<span class="token punctuation">(<span class="token parameter">res <span class="token operator">=> res<span class="token punctuation">.<span class="token function">json<span class="token punctuation">(<span class="token punctuation">)<span class="token punctuation">)<span class="token punctuation">.<span class="token function">tehn<span class="token punctuation">(<span class="token parameter">res <span class="token operator">=> <span class="token punctuation">{console<span class="token punctuation">.<span class="token function">log<span class="token punctuation">(res<span class="token punctuation">)<span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">;
  	<span class="token comment">// type3
  	<span class="token keyword">var xhr <span class="token operator">= <span class="token keyword">new <span class="token class-name">XMLHttpRequest<span class="token punctuation">(<span class="token punctuation">)<span class="token punctuation">;
    xhr<span class="token punctuation">.<span class="token function">open<span class="token punctuation">(<span class="token string">'POST'<span class="token punctuation">, <span class="token string">'http://localhost:7787/files'<span class="token punctuation">, <span class="token boolean">true<span class="token punctuation">)<span class="token punctuation">;
    xhr<span class="token punctuation">.<span class="token function-variable function">onload <span class="token operator">= <span class="token keyword">function <span class="token punctuation">(<span class="token punctuation">) <span class="token punctuation">{
    	console<span class="token punctuation">.<span class="token function">log<span class="token punctuation">(xhr<span class="token punctuation">.responseText<span class="token punctuation">)<span class="token punctuation">;
    <span class="token punctuation">}<span class="token punctuation">;
    xhr<span class="token punctuation">.<span class="token function">send<span class="token punctuation">(form<span class="token punctuation">)<span class="token punctuation">;
<span class="token punctuation">}
<span class="token tag"><span class="token tag"><span class="token punctuation"></script<span class="token punctuation">>
</span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></code></pre>
</div>
<p><img src="https://s3.qiufengh.com/blog/image-20200328192539734.png" alt="image-20200328192539734"></p>
<p>以上几种方式都是可以的。但是呢，请求库这么多，我随便在 npm 上一搜就有几百个请求相关的库。</p>
<p><img src="https://s3.qiufengh.com/blog/image-20200328194431932.png" alt="image-20200328194431932"></p>
<p>因此，掌握请求库的写法并不是我们的目标，目标只有一个还是掌握文件上传的请求头和请求内容。</p>
<p><img src="https://s3.qiufengh.com/blog/image-20200328194625420.png" alt="image-20200328194625420"></p>
<h2 id="blob"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#blob">#</a>Blob</h2>
<p><code>Blob</code> 对象表示一个不可变、原始数据的类文件对象。Blob 表示的不一定是JavaScript原生格式的数据。<a href="https://developer.mozilla.org/zh-CN/docs/Web/API/File" rel="noopener noreferrer" target="_blank"><code>File</code></a> 接口基于<code>Blob</code>，继承了 blob 的功能并将其扩展使其支持用户系统上的文件。</p>
<p>因此如果我们遇到 Blob 方式的文件上方式不用害怕，可以用以下两种方式:</p>
<p>1.直接使用 blob 上传</p>
<div class="language-javascript extra-class">
<pre class="language-javascript"><code><span class="token keyword">const json <span class="token operator">= <span class="token punctuation">{ hello<span class="token operator">: <span class="token string">"world" <span class="token punctuation">}<span class="token punctuation">;
<span class="token keyword">const blob <span class="token operator">= <span class="token keyword">new <span class="token class-name">Blob<span class="token punctuation">(<span class="token punctuation">[<span class="token constant">JSON<span class="token punctuation">.<span class="token function">stringify<span class="token punctuation">(json<span class="token punctuation">, <span class="token keyword">null<span class="token punctuation">, <span class="token number">2<span class="token punctuation">)<span class="token punctuation">]<span class="token punctuation">, <span class="token punctuation">{ type<span class="token operator">: <span class="token string">'application/json' <span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">;
    
<span class="token keyword">const form <span class="token operator">= <span class="token keyword">new <span class="token class-name">FormData<span class="token punctuation">(<span class="token punctuation">)<span class="token punctuation">;
form<span class="token punctuation">.<span class="token function">append<span class="token punctuation">(<span class="token string">'file'<span class="token punctuation">, blob<span class="token punctuation">, <span class="token string">'1.json'<span class="token punctuation">)<span class="token punctuation">;
axios<span class="token punctuation">.<span class="token function">post<span class="token punctuation">(<span class="token string">'http://localhost:7787/files'<span class="token punctuation">, form<span class="token punctuation">)<span class="token punctuation">;
</span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></code></pre>
</div>
<p>2.使用 File 对象，再进行一次包装（File 兼容性可能会差一些 https://caniuse.com/#search=File）</p>
<div class="language-javascript extra-class">
<pre class="language-javascript"><code><span class="token keyword">const json <span class="token operator">= <span class="token punctuation">{ hello<span class="token operator">: <span class="token string">"world" <span class="token punctuation">}<span class="token punctuation">;
<span class="token keyword">const blob <span class="token operator">= <span class="token keyword">new <span class="token class-name">Blob<span class="token punctuation">(<span class="token punctuation">[<span class="token constant">JSON<span class="token punctuation">.<span class="token function">stringify<span class="token punctuation">(json<span class="token punctuation">, <span class="token keyword">null<span class="token punctuation">, <span class="token number">2<span class="token punctuation">)<span class="token punctuation">]<span class="token punctuation">, <span class="token punctuation">{ type<span class="token operator">: <span class="token string">'application/json' <span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">;
    
<span class="token keyword">const file <span class="token operator">= <span class="token keyword">new <span class="token class-name">File<span class="token punctuation">(<span class="token punctuation">[blob<span class="token punctuation">]<span class="token punctuation">, <span class="token string">'1.json'<span class="token punctuation">)<span class="token punctuation">;
form<span class="token punctuation">.<span class="token function">append<span class="token punctuation">(<span class="token string">'file'<span class="token punctuation">, file<span class="token punctuation">)<span class="token punctuation">;
axios<span class="token punctuation">.<span class="token function">post<span class="token punctuation">(<span class="token string">'http://localhost:7787/files'<span class="token punctuation">, form<span class="token punctuation">)
</span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></code></pre>
</div>
<h2 id="arraybuffer"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#arraybuffer">#</a>ArrayBuffer</h2>
<p><code>ArrayBuffer</code> 对象用来表示通用的、固定长度的原始二进制数据缓冲区。</p>
<p>虽然它用的比较少，但是他是最贴近文件流的方式了。</p>
<p>在浏览器中，他每个字节以十进制的方式存在。我提前准备了一张图片。</p>
<div class="language-javascript extra-class">
<pre class="language-javascript"><code><span class="token keyword">const bufferArrary <span class="token operator">= <span class="token punctuation">[<span class="token number">137<span class="token punctuation">,<span class="token number">80<span class="token punctuation">,<span class="token number">78<span class="token punctuation">,<span class="token number">71<span class="token punctuation">,<span class="token number">13<span class="token punctuation">,<span class="token number">10<span class="token punctuation">,<span class="token number">26<span class="token punctuation">,<span class="token number">10<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">13<span class="token punctuation">,<span class="token number">73<span class="token punctuation">,<span class="token number">72<span class="token punctuation">,<span class="token number">68<span class="token punctuation">,<span class="token number">82<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">1<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">1<span class="token punctuation">,<span class="token number">1<span class="token punctuation">,<span class="token number">3<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">37<span class="token punctuation">,<span class="token number">219<span class="token punctuation">,<span class="token number">86<span class="token punctuation">,<span class="token number">202<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">6<span class="token punctuation">,<span class="token number">80<span class="token punctuation">,<span class="token number">76<span class="token punctuation">,<span class="token number">84<span class="token punctuation">,<span class="token number">69<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">255<span class="token punctuation">,<span class="token number">128<span class="token punctuation">,<span class="token number">128<span class="token punctuation">,<span class="token number">128<span class="token punctuation">,<span class="token number">76<span class="token punctuation">,<span class="token number">108<span class="token punctuation">,<span class="token number">191<span class="token punctuation">,<span class="token number">213<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">9<span class="token punctuation">,<span class="token number">112<span class="token punctuation">,<span class="token number">72<span class="token punctuation">,<span class="token number">89<span class="token punctuation">,<span class="token number">115<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">14<span class="token punctuation">,<span class="token number">196<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">14<span class="token punctuation">,<span class="token number">196<span class="token punctuation">,<span class="token number">1<span class="token punctuation">,<span class="token number">149<span class="token punctuation">,<span class="token number">43<span class="token punctuation">,<span class="token number">14<span class="token punctuation">,<span class="token number">27<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">10<span class="token punctuation">,<span class="token number">73<span class="token punctuation">,<span class="token number">68<span class="token punctuation">,<span class="token number">65<span class="token punctuation">,<span class="token number">84<span class="token punctuation">,<span class="token number">8<span class="token punctuation">,<span class="token number">153<span class="token punctuation">,<span class="token number">99<span class="token punctuation">,<span class="token number">96<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">2<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">1<span class="token punctuation">,<span class="token number">244<span class="token punctuation">,<span class="token number">113<span class="token punctuation">,<span class="token number">100<span class="token punctuation">,<span class="token number">166<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">0<span class="token punctuation">,<span class="token number">73<span class="token punctuation">,<span class="token number">69<span class="token punctuation">,<span class="token number">78<span class="token punctuation">,<span class="token number">68<span class="token punctuation">,<span class="token number">174<span class="token punctuation">,<span class="token number">66<span class="token punctuation">,<span class="token number">96<span class="token punctuation">,<span class="token number">130<span class="token punctuation">]<span class="token punctuation">;
<span class="token keyword">const array <span class="token operator">= Uint8Array<span class="token punctuation">.<span class="token function">from<span class="token punctuation">(bufferArrary<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const blob <span class="token operator">= <span class="token keyword">new <span class="token class-name">Blob<span class="token punctuation">(<span class="token punctuation">[array<span class="token punctuation">]<span class="token punctuation">, <span class="token punctuation">{type<span class="token operator">: <span class="token string">'image/png'<span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const form <span class="token operator">= <span class="token keyword">new <span class="token class-name">FormData<span class="token punctuation">(<span class="token punctuation">)<span class="token punctuation">;
form<span class="token punctuation">.<span class="token function">append<span class="token punctuation">(<span class="token string">'file'<span class="token punctuation">, blob<span class="token punctuation">, <span class="token string">'1.png'<span class="token punctuation">)<span class="token punctuation">;
axios<span class="token punctuation">.<span class="token function">post<span class="token punctuation">(<span class="token string">'http://localhost:7787/files'<span class="token punctuation">, form<span class="token punctuation">)
</span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></code></pre>
</div>
<p>这里需要注意的是 <code>new Blob([typedArray.buffer], {type: 'xxx'})</code>，第一个参数是由一个数组包裹。里面是 <code>typedArray</code> 类型的 buffer。</p>
<h2 id="base64"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#base64">#</a>Base64</h2>
<div class="language-javascript extra-class">
<pre class="language-javascript"><code><span class="token keyword">const base64 <span class="token operator">= <span class="token string">'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABAQMAAAAl21bKAAAABlBMVEUAAP+AgIBMbL/VAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAACklEQVQImWNgAAAAAgAB9HFkpgAAAABJRU5ErkJggg=='<span class="token punctuation">;
<span class="token keyword">const byteCharacters <span class="token operator">= <span class="token function">atob<span class="token punctuation">(base64<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const byteNumbers <span class="token operator">= <span class="token keyword">new <span class="token class-name">Array<span class="token punctuation">(byteCharacters<span class="token punctuation">.length<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">for <span class="token punctuation">(<span class="token keyword">let i <span class="token operator">= <span class="token number">0<span class="token punctuation">; i <span class="token operator">< byteCharacters<span class="token punctuation">.length<span class="token punctuation">; i<span class="token operator">++<span class="token punctuation">) <span class="token punctuation">{
	byteNumbers<span class="token punctuation">[i<span class="token punctuation">] <span class="token operator">= byteCharacters<span class="token punctuation">.<span class="token function">charCodeAt<span class="token punctuation">(i<span class="token punctuation">)<span class="token punctuation">;
<span class="token punctuation">}
<span class="token keyword">const array <span class="token operator">= Uint8Array<span class="token punctuation">.<span class="token function">from<span class="token punctuation">(byteNumbers<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const blob <span class="token operator">= <span class="token keyword">new <span class="token class-name">Blob<span class="token punctuation">(<span class="token punctuation">[array<span class="token punctuation">]<span class="token punctuation">, <span class="token punctuation">{type<span class="token operator">: <span class="token string">'image/png'<span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const form <span class="token operator">= <span class="token keyword">new <span class="token class-name">FormData<span class="token punctuation">(<span class="token punctuation">)<span class="token punctuation">;
form<span class="token punctuation">.<span class="token function">append<span class="token punctuation">(<span class="token string">'file'<span class="token punctuation">, blob<span class="token punctuation">, <span class="token string">'1.png'<span class="token punctuation">)<span class="token punctuation">;
axios<span class="token punctuation">.<span class="token function">post<span class="token punctuation">(<span class="token string">'http://localhost:7787/files'<span class="token punctuation">, form<span class="token punctuation">)<span class="token punctuation">;
</span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></code></pre>
</div>
<p>关于 base64 的转化和原理可以看这两篇 <a href="https://blog.csdn.net/wo541075754/article/details/81734770" rel="noopener noreferrer" target="_blank">base64 原理</a> 和</p>
<p><a href="https://www.zhangxinxu.com/wordpress/2018/08/js-base64-atob-btoa-encode-decode/" rel="noopener noreferrer" target="_blank">原来浏览器原生支持JS Base64编码解码</a></p>
<h2 id="小结"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#%E5%B0%8F%E7%BB%93">#</a>小结</h2>
<p>对于浏览器端的文件上传，可以归结出一个套路，所有东西核心思路就是构造出 <code>File</code> 对象。然后观察请求 <code>Content-Type</code>，再看请求体是否有信息缺失。而以上这些二进制数据类型的转化可以看以下表。</p>
<p><img src="https://s3.qiufengh.com/blog/transform.77175c26.jpg" alt="transform.77175c26"></p>
<p>图片来源 (<a href="https://shanyue.tech/post/binary-in-frontend/#%E6%95%B0%E6%8D%AE%E8%BE%93%E5%85%A5" rel="noopener noreferrer" target="_blank">https://shanyue.tech/post/binary-in-frontend/#%E6%95%B0%E6%8D%AE%E8%BE%93%E5%85%A5</a>)</p>
<h2 id="服务端"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#%E6%9C%8D%E5%8A%A1%E7%AB%AF">#</a>服务端</h2>
<p>讲完了浏览器端，现在我们来讲服务器端，和浏览器不同的是，服务端上传有两个难点。</p>
<p>1.浏览器没有原生 <code>formData</code>，也不会想浏览器一样帮我们转成二进制形式。</p>
<p>2.服务端没有可视化的 <code>Network</code> 调试器。</p>
<h2 id="buffer"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#buffer">#</a>Buffer</h2>
<h2 id="request"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#request">#</a>Request</h2>
<p>首先我们通过最简单的示例来进行演示，然后一步一步深入。相信文档可以查看 https://github.com/request/request#multipartform-data-multipart-form-uploads</p>
<div class="language-javascript extra-class">
<pre class="language-javascript"><code><span class="token comment">// request-error.js
<span class="token keyword">const fs <span class="token operator">= <span class="token function">require<span class="token punctuation">(<span class="token string">'fs'<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const path <span class="token operator">= <span class="token function">require<span class="token punctuation">(<span class="token string">'path'<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const request <span class="token operator">= <span class="token function">require<span class="token punctuation">(<span class="token string">'request'<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const stream <span class="token operator">= fs<span class="token punctuation">.<span class="token function">readFileSync<span class="token punctuation">(path<span class="token punctuation">.<span class="token function">join<span class="token punctuation">(__dirname<span class="token punctuation">, <span class="token string">'../1.png'<span class="token punctuation">)<span class="token punctuation">)<span class="token punctuation">;
request<span class="token punctuation">.<span class="token function">post<span class="token punctuation">(<span class="token punctuation">{
    url<span class="token operator">: <span class="token string">'http://localhost:7787/files'<span class="token punctuation">,
    formData<span class="token operator">: <span class="token punctuation">{
        file<span class="token operator">: stream<span class="token punctuation">,
    <span class="token punctuation">}
<span class="token punctuation">}<span class="token punctuation">, <span class="token punctuation">(<span class="token parameter">err<span class="token punctuation">, res<span class="token punctuation">, body<span class="token punctuation">) <span class="token operator">=> <span class="token punctuation">{
    console<span class="token punctuation">.<span class="token function">log<span class="token punctuation">(body<span class="token punctuation">)<span class="token punctuation">;
<span class="token punctuation">}<span class="token punctuation">)
</span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></code></pre>
</div>
<p><img src="https://s3.qiufengh.com/blog/image-20200328234106276.png" alt="image-20200328234106276"></p>
<p>发现报了一个错误，正像上面所说，浏览器端报错，可以用<code>NetWork</code>。那么服务端怎么办？这个时候我们拿出我们的利器 -- <code>wireshark</code></p>
<p>我们打开 <code>wireshark</code> （如果没有或者不会的可以查看教程 https://blog.csdn.net/u013613428/article/details/53156957）</p>
<p>设置配置 <code>tcp.port == 7787</code>,这个是我们后端的端口。</p>
<p><img src="https://s3.qiufengh.com/blog/image-20200328234316233.png" alt="image-20200328234316233"></p>
<p>运行上述文件 <code>node request-error.js</code></p>
<p><img src="https://s3.qiufengh.com/blog/image-20200328234543643.png" alt="image-20200328234543643"></p>
<p>我们来找到我们发送的这条<code>http</code>的请求报文。中间那堆乱七八糟的就是我们的文件内容。</p>
<div class="language- extra-class">
<pre class="language-text"><code>POST /files HTTP/1.1
host: localhost:7787
content-type: multipart/form-data; boundary=--------------------------437240798074408070374415
content-length: 305
Connection: close

----------------------------437240798074408070374415
Content-Disposition: form-data; name="file"
Content-Type: application/octet-stream

.PNG
.
...
IHDR.............%.V.....PLTE......Ll.....	pHYs..........+.....
IDAT..c`.......qd.....IEND.B`.
----------------------------437240798074408070374415--
</code></pre>
</div>
<p>可以看到上述报文。发现我们的内容请求头 <code>Content-Type: application/octet-stream</code>有错误,我们上传的是图片请求头应该是<code>image/png</code>，并且也少了 <code>filename="1.png"</code>。</p>
<p>我们来思考一下，我们刚才用的是<code>fs.readFileSync(path.join(__dirname, '../1.png'))</code> 这个函数返回的是 <code>Buffer</code>，<code>Buffer</code>是什么样的呢？就是下面的形式，不会包含任何文件相关的信息，只有二进制流。</p>
<div class="language- extra-class">
<pre class="language-text"><code><Buffer 01 02>
</code></pre>
</div>
<p>所以我想到的是，需要指定文件名以及文件格式，幸好 <code>request</code> 也给我们提供了这个选项。</p>
<div class="language- extra-class">
<pre class="language-text"><code>key: {
    value:  fs.createReadStream('/dev/urandom'),
    options: {
      filename: 'topsecret.jpg',
      contentType: 'image/jpeg'
    }
}
</code></pre>
</div>
<p>可以指定<code>options</code>,因此正确的代码应该如下(省略不重要的代码)</p>
<div class="language- extra-class">
<pre class="language-text"><code>...
request.post({
    url: 'http://localhost:7787/files',
    formData: {
        file: {
            value: stream,
            options: {
                filename: '1.png'
            }
        },
    }
});
</code></pre>
</div>
<p>我们通过抓包可以进行分析到，文件上传的要点还是规范，大部分的问题，都可以通过规范模板来进行排查，是否构造出了规范的样子。</p>
<h2 id="form-data"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#form-data">#</a>Form-data</h2>
<p>我们再深入一些，来看看 <code>request</code> 的源码, 他是怎么实现<code>Node</code>端的数据传输的。</p>
<p>打开源码我们很容易地就可以找到关于 formData 这块相关的内容 https://github.com/request/request/blob/3.0/request.js#L21</p>
<p><img src="https://s3.qiufengh.com/blog/image-20200328235629308.png" alt="image-20200328235629308"></p>
<p>就是利用<code>form-data</code>，我们先来看看 <code>formData</code> 的方式。</p>
<div class="language-javascript extra-class">
<pre class="language-javascript"><code><span class="token keyword">const path <span class="token operator">= <span class="token function">require<span class="token punctuation">(<span class="token string">'path'<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const FormData <span class="token operator">= <span class="token function">require<span class="token punctuation">(<span class="token string">'form-data'<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const fs <span class="token operator">= <span class="token function">require<span class="token punctuation">(<span class="token string">'fs'<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const http <span class="token operator">= <span class="token function">require<span class="token punctuation">(<span class="token string">'http'<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const form <span class="token operator">= <span class="token keyword">new <span class="token class-name">FormData<span class="token punctuation">(<span class="token punctuation">)<span class="token punctuation">;
form<span class="token punctuation">.<span class="token function">append<span class="token punctuation">(<span class="token string">'file'<span class="token punctuation">, fs<span class="token punctuation">.<span class="token function">readFileSync<span class="token punctuation">(path<span class="token punctuation">.<span class="token function">join<span class="token punctuation">(__dirname<span class="token punctuation">, <span class="token string">'../1.png'<span class="token punctuation">)<span class="token punctuation">)<span class="token punctuation">, <span class="token punctuation">{
    filename<span class="token operator">: <span class="token string">'1.png'<span class="token punctuation">,
    contentType<span class="token operator">: <span class="token string">'image/jpeg'<span class="token punctuation">,
<span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const request <span class="token operator">= http<span class="token punctuation">.<span class="token function">request<span class="token punctuation">(<span class="token punctuation">{
    method<span class="token operator">: <span class="token string">'post'<span class="token punctuation">,
    host<span class="token operator">: <span class="token string">'localhost'<span class="token punctuation">,
    port<span class="token operator">: <span class="token string">'7787'<span class="token punctuation">,
    path<span class="token operator">: <span class="token string">'/files'<span class="token punctuation">,
    headers<span class="token operator">: form<span class="token punctuation">.<span class="token function">getHeaders<span class="token punctuation">(<span class="token punctuation">)
<span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">;
form<span class="token punctuation">.<span class="token function">pipe<span class="token punctuation">(request<span class="token punctuation">)<span class="token punctuation">;
request<span class="token punctuation">.<span class="token function">on<span class="token punctuation">(<span class="token string">'response'<span class="token punctuation">, <span class="token keyword">function<span class="token punctuation">(<span class="token parameter">res<span class="token punctuation">) <span class="token punctuation">{
    console<span class="token punctuation">.<span class="token function">log<span class="token punctuation">(res<span class="token punctuation">.statusCode<span class="token punctuation">)<span class="token punctuation">;
<span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">;
</span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></code></pre>
</div>
<h2 id="原生-node"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#%E5%8E%9F%E7%94%9F-node">#</a>原生 Node</h2>
<p>看完<code>formData</code>,可能感觉这个封装还是太高层了，于是我打算对照规范手动来构造<code>multipart/form-data</code>请求方式来进行讲解。我们再来回顾一下规范。</p>
<div class="language- extra-class">
<pre class="language-text"><code>Content-type: multipart/form-data, boundary=AaB03x

--AaB03x
content-disposition: form-data; name="field1"
Joe Blow
--AaB03x
content-disposition: form-data; name="pics"; filename="file1.txt"
Content-Type: text/plain

... contents of file1.txt ...
--AaB03x--
</code></pre>
</div>
<p>我模拟上方，我用原生 <code>Node</code> 写出了一个<code>multipart/form-data</code> 请求的方式。</p>
<h2 id="主要分为4个部分"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#%E4%B8%BB%E8%A6%81%E5%88%86%E4%B8%BA4%E4%B8%AA%E9%83%A8%E5%88%86">#</a>主要分为4个部分</h2>
<ul>
<li>
<p>构造请求header</p>
</li>
<li>
<p>构造内容header</p>
</li>
<li>
<p>写入内容</p>
</li>
<li>
<p>写入结束分隔符</p>
</li>
</ul>
<div class="language-javascript extra-class">
<pre class="language-javascript"><code><span class="token keyword">const path <span class="token operator">= <span class="token function">require<span class="token punctuation">(<span class="token string">'path'<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const fs <span class="token operator">= <span class="token function">require<span class="token punctuation">(<span class="token string">'fs'<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const http <span class="token operator">= <span class="token function">require<span class="token punctuation">(<span class="token string">'http'<span class="token punctuation">)<span class="token punctuation">;
<span class="token comment">// 定义一个分隔符，要确保唯一性
<span class="token keyword">const boundaryKey <span class="token operator">= <span class="token string">'-------------------------461591080941622511336662'<span class="token punctuation">;
<span class="token keyword">const request <span class="token operator">= http<span class="token punctuation">.<span class="token function">request<span class="token punctuation">(<span class="token punctuation">{
    method<span class="token operator">: <span class="token string">'post'<span class="token punctuation">,
    host<span class="token operator">: <span class="token string">'localhost'<span class="token punctuation">,
    port<span class="token operator">: <span class="token string">'7787'<span class="token punctuation">,
    path<span class="token operator">: <span class="token string">'/files'<span class="token punctuation">,
    headers<span class="token operator">: <span class="token punctuation">{
        <span class="token string">'Content-Type'<span class="token operator">: <span class="token string">'multipart/form-data; boundary=' <span class="token operator">+ boundaryKey<span class="token punctuation">, <span class="token comment">// 在请求头上加上分隔符
        <span class="token string">'Connection'<span class="token operator">: <span class="token string">'keep-alive'
    <span class="token punctuation">}
<span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">;
<span class="token comment">// 写入内容头部
request<span class="token punctuation">.<span class="token function">write<span class="token punctuation">(
    <span class="token template-string"><span class="token template-punctuation string">`<span class="token string">--<span class="token interpolation"><span class="token interpolation-punctuation punctuation">${boundaryKey<span class="token interpolation-punctuation punctuation">}<span class="token string">\r\nContent-Disposition: form-data; name="file"; filename="1.png"\r\nContent-Type: image/jpeg\r\n\r\n<span class="token template-punctuation string">`
<span class="token punctuation">)<span class="token punctuation">;
<span class="token comment">// 写入内容
<span class="token keyword">const fileStream <span class="token operator">= fs<span class="token punctuation">.<span class="token function">createReadStream<span class="token punctuation">(path<span class="token punctuation">.<span class="token function">join<span class="token punctuation">(__dirname<span class="token punctuation">, <span class="token string">'../1.png'<span class="token punctuation">)<span class="token punctuation">)<span class="token punctuation">;
fileStream<span class="token punctuation">.<span class="token function">pipe<span class="token punctuation">(request<span class="token punctuation">, <span class="token punctuation">{ end<span class="token operator">: <span class="token boolean">false <span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">;
fileStream<span class="token punctuation">.<span class="token function">on<span class="token punctuation">(<span class="token string">'end'<span class="token punctuation">, <span class="token keyword">function <span class="token punctuation">(<span class="token punctuation">) <span class="token punctuation">{
    <span class="token comment">// 写入尾部
    request<span class="token punctuation">.<span class="token function">end<span class="token punctuation">(<span class="token string">'\r\n--' <span class="token operator">+ boundaryKey <span class="token operator">+ <span class="token string">'--' <span class="token operator">+ <span class="token string">'\r\n'<span class="token punctuation">)<span class="token punctuation">;
<span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">;
request<span class="token punctuation">.<span class="token function">on<span class="token punctuation">(<span class="token string">'response'<span class="token punctuation">, <span class="token keyword">function<span class="token punctuation">(<span class="token parameter">res<span class="token punctuation">) <span class="token punctuation">{
    console<span class="token punctuation">.<span class="token function">log<span class="token punctuation">(res<span class="token punctuation">.statusCode<span class="token punctuation">)<span class="token punctuation">;
<span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">;
</span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></code></pre>
</div>
<p>至此，已经实现服务端上传文件的方式。</p>
<h2 id="stream、base64"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#stream%E3%80%81base64">#</a>Stream、Base64</h2>
<p>由于这两块就是和<code>Buffer</code>的转化，比较简单，我就不再重复描述了。可以作为留给大家的作业，感兴趣的可以给我这个示例代码仓库贡献这两个示例。</p>
<div class="language-javascript extra-class">
<pre class="language-javascript"><code><span class="token comment">// base64 to buffer
<span class="token keyword">const b64string <span class="token operator">= <span class="token comment">/* whatever */<span class="token punctuation">;
<span class="token keyword">const buf <span class="token operator">= Buffer<span class="token punctuation">.<span class="token function">from<span class="token punctuation">(b64string<span class="token punctuation">, <span class="token string">'base64'<span class="token punctuation">)<span class="token punctuation">;
</span></span></span></span></span></span></span></span></span></span></span></span></span></span></code></pre>
</div>
<div class="language-javascript extra-class">
<pre class="language-javascript"><code><span class="token comment">// stream to buffer
<span class="token keyword">function <span class="token function">streamToBuffer<span class="token punctuation">(<span class="token parameter">stream<span class="token punctuation">) <span class="token punctuation">{  
  <span class="token keyword">return <span class="token keyword">new <span class="token class-name">Promise<span class="token punctuation">(<span class="token punctuation">(<span class="token parameter">resolve<span class="token punctuation">, reject<span class="token punctuation">) <span class="token operator">=> <span class="token punctuation">{
    <span class="token keyword">const buffers <span class="token operator">= <span class="token punctuation">[<span class="token punctuation">]<span class="token punctuation">;
    stream<span class="token punctuation">.<span class="token function">on<span class="token punctuation">(<span class="token string">'error'<span class="token punctuation">, reject<span class="token punctuation">)<span class="token punctuation">;
    stream<span class="token punctuation">.<span class="token function">on<span class="token punctuation">(<span class="token string">'data'<span class="token punctuation">, <span class="token punctuation">(<span class="token parameter">data<span class="token punctuation">) <span class="token operator">=> buffers<span class="token punctuation">.<span class="token function">push<span class="token punctuation">(data<span class="token punctuation">)<span class="token punctuation">)
    stream<span class="token punctuation">.<span class="token function">on<span class="token punctuation">(<span class="token string">'end'<span class="token punctuation">, <span class="token punctuation">(<span class="token punctuation">) <span class="token operator">=> <span class="token function">resolve<span class="token punctuation">(Buffer<span class="token punctuation">.<span class="token function">concat<span class="token punctuation">(buffers<span class="token punctuation">)<span class="token punctuation">)<span class="token punctuation">)
  <span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">;
<span class="token punctuation">}
</span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></code></pre>
</div>
<h2 id="小结-2"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#%E5%B0%8F%E7%BB%93-2">#</a>小结</h2>
<p>由于服务端没有像浏览器那样 <code>formData</code> 的原生对象，因此服务端核心思路为构造出文件上传的格式(header,filename等)，然后写入 <code>buffer</code> 。然后千万别忘了用 <code>wireshark</code>进行验证。</p>
<h2 id="接收端"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#%E6%8E%A5%E6%94%B6%E7%AB%AF">#</a>接收端</h2>
<p>这一部分是针对 <code>Node</code> 端进行讲解，对于那些 <code>koa-body</code> 等用惯了的同学，可能一样不太清楚整个过程发生了什么？可能唯一比较清楚的是 <code>ctx.request.files</code> ??? 如果<code>ctx.request.files</code> 不存在，就会懵逼了，可能也不太清楚它到底做了什么，文件流又是怎么解析的。</p>
<p>我还是要说到规范...请求端是按照规范来构造请求..那么我们接收端自然是按照规范来解析请求了。</p>
<h2 id="koa-body"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#koa-body">#</a>Koa-body</h2>
<div class="language-javascript extra-class">
<pre class="language-javascript"><code><span class="token keyword">const koaBody <span class="token operator">= <span class="token function">require<span class="token punctuation">(<span class="token string">'koa-body'<span class="token punctuation">)<span class="token punctuation">;

app<span class="token punctuation">.<span class="token function">use<span class="token punctuation">(<span class="token function">koaBody<span class="token punctuation">(<span class="token punctuation">{ multipart<span class="token operator">: <span class="token boolean">true <span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">)<span class="token punctuation">;
</span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></code></pre>
</div>
<p>我们来看看最常用的 <code>koa-body</code>，它的使用方式非常简单，短短几行，就能让我们享受到文件上传的简单与快乐（其他源码库一样的思路去寻找问题的本源） 可以带着一个问题去阅读，为什么用了它就能解析出文件？</p>
<p>寻求问题的本源，我们当然要打开 <code>koa-body</code>的源码，<code>koa-body</code> 源码很少只有211行，https://github.com/dlau/koa-body/blob/v4.1.1/index.js#L125 很容易地发现它其实是用了一个叫做<code>formidable</code>的库来解析<code>files</code> 的。并且把解析好的<code>files</code> 对象赋值到了 <code>ctx.req.files</code>。（所以说大家不要一味死记 <code>ctx.request.files</code>, 注意查看文档，因为今天用 <code>koa-body</code>是 <code>ctx.request.files</code> 明天换个库可能就是 <code>ctx.request.body</code> 了）</p>
<p>因此看完<code>koa-body</code>我们得出的结论是，<code>koa-body</code>的核心方法是<code>formidable</code></p>
<h2 id="formidable"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#formidable">#</a>Formidable</h2>
<p>那么让我们继续深入，来看看<code>formidable</code>做了什么，我们首先来看它的目录结构。</p>
<div class="language- extra-class">
<pre class="language-text"><code>.
├── lib
│   ├── file.js
│   ├── incoming_form.js
│   ├── index.js
│   ├── json_parser.js
│   ├── multipart_parser.js
│   ├── octet_parser.js
│   └── querystring_parser.js
</code></pre>
</div>
<p>看到这个目录，我们大致可以梳理出这样的关系。</p>
<div class="language- extra-class">
<pre class="language-text"><code>index.js
|
incoming_form.js
|
type
?
|
1.json_parser
2.multipart_parser
3.octet_parser
4.querystring_parser
</code></pre>
</div>
<p>由于源码分析比较枯燥。因此我只摘录比较重要的片段。由于我们是分析文件上传，所以我们只需要关心<code>multipart_parser</code> 这个文件。</p>
<p>https://github.com/node-formidable/formidable/blob/v1.2.1/lib/multipart_parser.js#L72</p>
<div class="language- extra-class">
<pre class="language-text"><code>...
MultipartParser.prototype.write = function(buffer) {
	console.log(buffer);
  var self = this,
      i = 0,
      len = buffer.length,
      prevIndex = this.index,
      index = this.index,
      state = this.state,
...      
</code></pre>
</div>
<p>我们将它的 <code>buffer</code> 打印看看.</p>
<div class="language- extra-class">
<pre class="language-text"><code><Buffer 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 34 36 31 35 39 31 30 38 30 39 34 31 36 32 32 35 31 31 33 33 36 36 36 ... >
144
<Buffer 89 50 4e 47 0d 0a 1a 0a 00 00 00 0d 49 48 44 52 00 00 00 01 00 00 00 01 01 03 00 00 00 25 db 56 ca 00 00 00 06 50 4c 54 45 00 00 ff 80 80 80 4c 6c bf ... >
106
<Buffer 0d 0a 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 2d 34 36 31 35 39 31 30 38 30 39 34 31 36 32 32 35 31 31 33 33 36 ... >
</code></pre>
</div>
<p>我们来看<code>wireshark</code> 抓到的包</p>
<p><img src="https://s3.qiufengh.com/blog/image-20200329144355168.png" alt="image-20200329144355168"></p>
<p>我用红色进行了分割标记，对应的就是<code>formidable</code>所分割的片段 ，所以说这个包主要是将大段的 <code>buffer</code> 进行分割，然后循环处理。</p>
<blockquote>
<p>这里我还可以补充一下，可能你对以上表非常陌生。左侧是二进制流，每1个代表1个字节，1字节=8位，上面的 2d 其实就是16进制的表示形式，用二进制表示就是 0010 1101，右侧是ascii 码用来可视化，但是 assii 分可显和非可显示。有部分是无法可视的。比如你所看到文件中有需要小点，就是不可见字符。</p>
</blockquote>
<p>你可以对照，<a href="http://ascii.911cha.com/" rel="noopener noreferrer" target="_blank">ascii表对照表</a>来看。</p>
<p>我来总结一下<code>formidable</code>对于文件的处理流程。</p>
<p><img src="https://s3.qiufengh.com/blog/formible-process.png" alt="formible-process"></p>
<h2 id="原生-node-2"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#%E5%8E%9F%E7%94%9F-node-2">#</a>原生 Node</h2>
<p>好了，我们已经知道了文件处理的流程，那么我们自己来写一个吧。</p>
<div class="language-javascript extra-class">
<pre class="language-javascript"><code><span class="token keyword">const fs <span class="token operator">= <span class="token function">require<span class="token punctuation">(<span class="token string">'fs'<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const http <span class="token operator">= <span class="token function">require<span class="token punctuation">(<span class="token string">'http'<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const querystring <span class="token operator">= <span class="token function">require<span class="token punctuation">(<span class="token string">'querystring'<span class="token punctuation">)<span class="token punctuation">;
<span class="token keyword">const server <span class="token operator">= http<span class="token punctuation">.<span class="token function">createServer<span class="token punctuation">(<span class="token punctuation">(<span class="token parameter">req<span class="token punctuation">, res<span class="token punctuation">) <span class="token operator">=> <span class="token punctuation">{
  <span class="token keyword">if <span class="token punctuation">(req<span class="token punctuation">.url <span class="token operator">=== <span class="token string">"/files" <span class="token operator">&& req<span class="token punctuation">.method<span class="token punctuation">.<span class="token function">toLowerCase<span class="token punctuation">(<span class="token punctuation">) <span class="token operator">=== <span class="token string">"post"<span class="token punctuation">) <span class="token punctuation">{
    <span class="token function">parseFile<span class="token punctuation">(req<span class="token punctuation">, res<span class="token punctuation">)
  <span class="token punctuation">}
<span class="token punctuation">}<span class="token punctuation">)
<span class="token keyword">function <span class="token function">parseFile<span class="token punctuation">(<span class="token parameter">req<span class="token punctuation">, res<span class="token punctuation">) <span class="token punctuation">{
  req<span class="token punctuation">.<span class="token function">setEncoding<span class="token punctuation">(<span class="token string">"binary"<span class="token punctuation">)<span class="token punctuation">;
  <span class="token keyword">let body <span class="token operator">= <span class="token string">""<span class="token punctuation">;
  <span class="token keyword">let fileName <span class="token operator">= <span class="token string">""<span class="token punctuation">;
  <span class="token comment">// 边界字符
  <span class="token keyword">let boundary <span class="token operator">= req<span class="token punctuation">.headers<span class="token punctuation">[<span class="token string">'content-type'<span class="token punctuation">]
    <span class="token punctuation">.<span class="token function">split<span class="token punctuation">(<span class="token string">'; '<span class="token punctuation">)<span class="token punctuation">[<span class="token number">1<span class="token punctuation">]
    <span class="token punctuation">.<span class="token function">replace<span class="token punctuation">(<span class="token string">"boundary="<span class="token punctuation">, <span class="token string">""<span class="token punctuation">)
  
  req<span class="token punctuation">.<span class="token function">on<span class="token punctuation">(<span class="token string">"data"<span class="token punctuation">, <span class="token keyword">function<span class="token punctuation">(<span class="token parameter">chunk<span class="token punctuation">) <span class="token punctuation">{
    body <span class="token operator">+= chunk<span class="token punctuation">;
  <span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">;
  req<span class="token punctuation">.<span class="token function">on<span class="token punctuation">(<span class="token string">"end"<span class="token punctuation">, <span class="token keyword">function<span class="token punctuation">(<span class="token punctuation">) <span class="token punctuation">{
    <span class="token comment">// 按照分解符切分
    <span class="token keyword">const list <span class="token operator">= body<span class="token punctuation">.<span class="token function">split<span class="token punctuation">(boundary<span class="token punctuation">)<span class="token punctuation">;
    <span class="token keyword">let contentType <span class="token operator">= <span class="token string">''<span class="token punctuation">;
    <span class="token keyword">let fileName <span class="token operator">= <span class="token string">''<span class="token punctuation">;
    <span class="token keyword">for <span class="token punctuation">(<span class="token keyword">let i <span class="token operator">= <span class="token number">0<span class="token punctuation">; i <span class="token operator">< list<span class="token punctuation">.length<span class="token punctuation">; i<span class="token operator">++<span class="token punctuation">) <span class="token punctuation">{
      <span class="token keyword">if <span class="token punctuation">(list<span class="token punctuation">[i<span class="token punctuation">]<span class="token punctuation">.<span class="token function">includes<span class="token punctuation">(<span class="token string">'Content-Disposition'<span class="token punctuation">)<span class="token punctuation">) <span class="token punctuation">{
        <span class="token keyword">const data <span class="token operator">= list<span class="token punctuation">[i<span class="token punctuation">]<span class="token punctuation">.<span class="token function">split<span class="token punctuation">(<span class="token string">'\r\n'<span class="token punctuation">)<span class="token punctuation">;
        <span class="token keyword">for <span class="token punctuation">(<span class="token keyword">let j <span class="token operator">= <span class="token number">0<span class="token punctuation">; j <span class="token operator">< data<span class="token punctuation">.length<span class="token punctuation">; j<span class="token operator">++<span class="token punctuation">) <span class="token punctuation">{
          <span class="token comment">// 从头部拆分出名字和类型
          <span class="token keyword">if <span class="token punctuation">(data<span class="token punctuation">[j<span class="token punctuation">]<span class="token punctuation">.<span class="token function">includes<span class="token punctuation">(<span class="token string">'Content-Disposition'<span class="token punctuation">)<span class="token punctuation">) <span class="token punctuation">{
            <span class="token keyword">const info <span class="token operator">= data<span class="token punctuation">[j<span class="token punctuation">]<span class="token punctuation">.<span class="token function">split<span class="token punctuation">(<span class="token string">':'<span class="token punctuation">)<span class="token punctuation">[<span class="token number">1<span class="token punctuation">]<span class="token punctuation">.<span class="token function">split<span class="token punctuation">(<span class="token string">';'<span class="token punctuation">)<span class="token punctuation">;
            fileName <span class="token operator">= info<span class="token punctuation">[info<span class="token punctuation">.length <span class="token operator">- <span class="token number">1<span class="token punctuation">]<span class="token punctuation">.<span class="token function">split<span class="token punctuation">(<span class="token string">'='<span class="token punctuation">)<span class="token punctuation">[<span class="token number">1<span class="token punctuation">]<span class="token punctuation">.<span class="token function">replace<span class="token punctuation">(<span class="token regex">/"/g<span class="token punctuation">, <span class="token string">''<span class="token punctuation">)<span class="token punctuation">;
            console<span class="token punctuation">.<span class="token function">log<span class="token punctuation">(fileName<span class="token punctuation">)<span class="token punctuation">;
          <span class="token punctuation">}
          <span class="token keyword">if <span class="token punctuation">(data<span class="token punctuation">[j<span class="token punctuation">]<span class="token punctuation">.<span class="token function">includes<span class="token punctuation">(<span class="token string">'Content-Type'<span class="token punctuation">)<span class="token punctuation">) <span class="token punctuation">{
            contentType <span class="token operator">= data<span class="token punctuation">[j<span class="token punctuation">]<span class="token punctuation">;
            console<span class="token punctuation">.<span class="token function">log<span class="token punctuation">(data<span class="token punctuation">[j<span class="token punctuation">]<span class="token punctuation">.<span class="token function">split<span class="token punctuation">(<span class="token string">':'<span class="token punctuation">)<span class="token punctuation">[<span class="token number">1<span class="token punctuation">]<span class="token punctuation">)<span class="token punctuation">;
          <span class="token punctuation">}
        <span class="token punctuation">}
      <span class="token punctuation">}
    <span class="token punctuation">}
    <span class="token comment">// 去除前面的请求头
    <span class="token keyword">const start <span class="token operator">= body<span class="token punctuation">.<span class="token function">toString<span class="token punctuation">(<span class="token punctuation">)<span class="token punctuation">.<span class="token function">indexOf<span class="token punctuation">(contentType<span class="token punctuation">) <span class="token operator">+ contentType<span class="token punctuation">.length <span class="token operator">+ <span class="token number">4<span class="token punctuation">; <span class="token comment">// 有多\r\n\r\n
    <span class="token keyword">const startBinary <span class="token operator">= body<span class="token punctuation">.<span class="token function">toString<span class="token punctuation">(<span class="token punctuation">)<span class="token punctuation">.<span class="token function">substring<span class="token punctuation">(start<span class="token punctuation">)<span class="token punctuation">;
    <span class="token keyword">const end <span class="token operator">= startBinary<span class="token punctuation">.<span class="token function">indexOf<span class="token punctuation">(<span class="token string">"--" <span class="token operator">+ boundary <span class="token operator">+ <span class="token string">"--"<span class="token punctuation">) <span class="token operator">- <span class="token number">2<span class="token punctuation">; <span class="token comment">// 前面有多\r\n
     <span class="token comment">// 去除后面的分隔符
    <span class="token keyword">const binary <span class="token operator">= startBinary<span class="token punctuation">.<span class="token function">substring<span class="token punctuation">(<span class="token number">0<span class="token punctuation">, end<span class="token punctuation">)<span class="token punctuation">;
    <span class="token keyword">const bufferData <span class="token operator">= Buffer<span class="token punctuation">.<span class="token function">from<span class="token punctuation">(binary<span class="token punctuation">, <span class="token string">"binary"<span class="token punctuation">)<span class="token punctuation">;
    fs<span class="token punctuation">.<span class="token function">writeFile<span class="token punctuation">(fileName<span class="token punctuation">, bufferData<span class="token punctuation">, <span class="token keyword">function<span class="token punctuation">(<span class="token parameter">err<span class="token punctuation">) <span class="token punctuation">{
      res<span class="token punctuation">.<span class="token function">end<span class="token punctuation">(<span class="token string">"sucess"<span class="token punctuation">)<span class="token punctuation">;
    <span class="token punctuation">}<span class="token punctuation">)<span class="token punctuation">;
    <span class="token punctuation">;
  <span class="token punctuation">}<span class="token punctuation">)
<span class="token punctuation">}

server<span class="token punctuation">.<span class="token function">listen<span class="token punctuation">(<span class="token number">7787<span class="token punctuation">)

</span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></span></code></pre>
</div>
<h2 id="总结"><a class="header-anchor" href="https://qiufeng.blue/node/upload.html#%E6%80%BB%E7%BB%93">#</a>总结</h2>
<p>以上所有示例代码仓库: https://github.com/hua1995116/node-upload-demo</p>
<p>相信有了以上的介绍，你不再对文件上传有所惧怕, 对文件上传整个过程都会比较清晰了，还不懂。。。。找我。</p>
<p>再次回顾下我们的重点:</p>
<p>请求端出问题，浏览器端打开 <code>network</code> 查看格式是否正确（请求头，请求体）, 如果数据不够详细，打开<code>wireshark</code>，对照我们的规范标准，看下格式（请求头，请求体）。</p>
<p>接收端出问题，情况一就是请求端缺少信息，参考上面请求端出问题的情况，情况二请求体内容错误，如果说请求体内容是请求端自己构造的，那么需要检查请求体是否是正确的二进制流（例如上面的blob构造的时候，我一开始少了一个[]，导致内容主体错误）。</p>
<p>其实讲这么多就两个字: <a href="https://www.ietf.org/rfc/rfc1867.txt" rel="noopener noreferrer" target="_blank">规范</a>，所有的生态都是围绕它而展开的。</p>
<p><span style="color: #ff0000;"><strong>原文链接 <a href="https://qiufeng.blue/node/upload.html" target="_blank"><span style="color: #ff0000;">https://qiufeng.blue/node/upload.html</span></a></strong></span></p>
</x-turndown>
```