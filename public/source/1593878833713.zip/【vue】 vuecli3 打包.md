vue-cli3 打包后 路径错误

1、新建 vue.config.js

module.exports = {
    publicPath: './',    
    lintOnSave:false     //关闭eslint 
}

2、router mode模式 设置为 hash