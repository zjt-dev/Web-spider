git fetch 时，提示错误 error: cannot lock ref 'refs/remotes/origin/xxx': unable to resolve reference 'refs/remotes/origin/xxx': reference broken。  
在使用 git fetch 命令之后，错误输出如下：

```
$ git fetch
Fetching origin
error: cannot lock ref 'refs/remotes/origin/next/release': unable to resolve reference 'refs/remotes/origin/next/release': reference broken
From git***.***.com:walterlv/demo-project
 ! [new branch]            next/release        -> origin/next/release  (unable to update local ref)
```

删除 .git\\refs\\remotes文件夹中对应失败的分支  
重新拉取

```
$ git fetch
Fetching origin
From gitlab.gz.cvte.cn:t/tech-app/dev/win/app/easinote
   a1fd2551f7..cfb662e870  next/release  -> origin/next/release
  [new branch]            feature/ai    -> origin/feature/ai
   97d72dfc8f..ceb346c8e2  release       -> origin/release
```