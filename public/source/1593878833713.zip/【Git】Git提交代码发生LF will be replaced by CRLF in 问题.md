原因是需要提交的文件是在windows下生成的，windows中的换行符为 CRLF， 而在linux下的换行符为LF，所以在执行add . 时出现提示，  
解决办法：  
git config --global core.autocrlf false  
再执行git 提交