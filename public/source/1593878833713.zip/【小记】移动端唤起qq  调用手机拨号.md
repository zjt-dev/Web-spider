### 移动端唤起qq

var u = navigator.userAgent;
        var isiOS = !!u.match(/\\(i\[^;\]+;( U;)? CPU.+Mac OS X/);
        var qqUrl = 'mqqwpa://im/chat?chat\_type=wpa&uin=QQ号&version=1&src\_type=web&web\_src=oicqzone.com';
        if(isiOS){
            if(u.toLowerCase().match(/MicroMessenger/i) == "micromessenger"){
                qqUrl = 'http://wpa.qq.com/msgrd?v=3&uin=QQ号&site=qq&menu=yes';
            }else{
                qqUrl = 'mqqwpa://im/chat?chat\_type=wpa&uin=QQ号&version=1&src\_type=web&web\_src=oicqzone.com';
            }
        }else{
            if(u.toLowerCase().match(/MicroMessenger/i) == "micromessenger"){
                qqUrl = 'http://wpa.qq.com/msgrd?v=3&uin=QQ号&site=qq&menu=yes';
            }else{
                qqUrl = 'mqqwpa://im/chat?chat\_type=wpa&uin=QQ号&version=1&src\_type=web&web\_src=oicqzone.com';
            }    
        }

### 调用手机拨号

[电话号](tel:电话号)