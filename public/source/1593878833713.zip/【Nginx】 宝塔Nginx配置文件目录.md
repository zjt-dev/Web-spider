### nginx.conf文件路径：**/www/server/nginx/conf/nginx.conf**

### 多域名Nginx配置文件：**/www/server/panel/vhost/nginx/你的域名.conf**