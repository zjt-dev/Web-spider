JavaScript在事件中调用函数时用return返回值实际上是对window.event.returnvalue（没听过）进行设置。  
  
而该值决定了当前操作是否继续。  
当返回的是true时，将继续操作。  
当返回是false时，将中断操作。  
  
  
而直接执行时（不用return）。将不会对window.event.returnvalue进行设置  
所以会默认地继续执行操作  
  
例如：

当在 [Open](abc.htm) 中  
如果函数 add\_onclick() 返回 true, 那么 页面就会打开 abc.htm  
否则, (返回 false), 那么页面不会跳转到 abc.htm, 只会执行你的 add\_onclick() 函数里的内容. (add\_onclick函数中控制页面转到 abc.htm除外  
  
)  
而 [Open](abc.htm)  
不管 add\_onclick() 返回什么值, 都会在执行完 add\_onclick 后打开页面 abc.htm

  
参考：[![返回主页](https://www.cnblogs.com/Skins/custom/images/logo.gif)  
](https://www.cnblogs.com/peijie-tech/)[Jack](https://www.cnblogs.com/peijie-tech/p/3748453.html)