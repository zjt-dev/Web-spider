```js
document.onkeydown = function (e) {
      var ev = document.all ? window.event : e;
      if (ev.keyCode == 13 && ev.ctrlKey) {
	document.getElementById("chatipt").value += "\n";
      } else if (ev.keyCode == 13) {
	// 避免回车键换行 取消事件的默认动作
	ev.preventDefault();
	// 下面写你的发送消息的代码
	sendMsg()
      }
}
```