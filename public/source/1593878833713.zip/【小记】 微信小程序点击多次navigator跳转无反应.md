## 微信小程序点击多次navigator跳转无反应

`navigator`组件 `open-type`属性默认值为`navigate`

而`navigate`对应`navigateTo`方法，可以看到文档中对`navigateTo`的说明：

保留当前页面，跳转到应用内的某个页面。但是不能跳到 tabbar 页面。使用 wx.navigateBack 可以返回到原页面。小程序中页面栈**最多十层**。

**将 `open-type`属性值设为`redirect`即可**

![](https://img2020.cnblogs.com/blog/1524685/202005/1524685-20200527215643179-1477381662.png)

![](https://img2020.cnblogs.com/blog/1524685/202005/1524685-20200527215457101-77247117.png)