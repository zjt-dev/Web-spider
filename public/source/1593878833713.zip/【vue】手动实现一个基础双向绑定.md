    
    Document

    

          
        
    
    

 <span style="color: #0000ff;">var</span> data =<span style="color: #000000;"> {
        message:</span>''<span style="color: #000000;">
    }
    </span><span style="color: #0000ff;">var</span> input = document.querySelector('\[v-model=message\]'<span style="color: #000000;">)
    input.onkeyup</span>=<span style="color: #0000ff;">function</span><span style="color: #000000;">(){
        data.message </span>=<span style="color: #000000;"> input.value
        </span><span style="color: #008000;">//</span><span style="color: #008000;"> data.message 发生改变 触发 Object.defineproperty</span>
<span style="color: #000000;">    }
    </span>
    <span style="color: #008000;">//</span><span style="color: #008000;"><span style="font-size: 15px;"><a href="https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global\_Objects/Object/defineProperty" target="\_blank">Object.defineProperty</a> </span>接受三个参数 </span>
    <span style="color: #008000;">//</span><span style="color: #008000;"> obj 要在其上定义属性的对象。</span>
    <span style="color: #008000;">//</span><span style="color: #008000;"> prop 要定义或修改的属性的名称。</span>
    <span style="color: #008000;">//</span><span style="color: #008000;"> descriptor 将被定义或修改的属性描述符。 仅用到 get 和 set 属性<br>　　 </span><span style="color: #339966;">// 这个方法会直接在一个对象上定义一个新属性或者修改对象上的现有属性，并返回该对象。</span></pre>
<pre>    Object.defineProperty(data, 'message'<span style="color: #000000;">, {
        </span><span style="color: #008000;">//</span><span style="color: #008000;"> set 接受唯一参数，即该属性新的参数值。</span>
<span style="color: #000000;">        set(newValue){
            </span><span style="color: #0000ff;">var</span> span = document.querySelector('\[v-bind=message\]'<span style="color: #000000;">)
            span.innerHTML</span>=<span style="color: #000000;">newValue<br>　　　　　　　this.value = newValue
        },
        </span><span style="color: #008000;">//</span><span style="color: #008000;"> get 方法执行时没有参数传入</span>
<span style="color: #000000;">        get(){<br>　　　　     <span style="color: #339966;">//将newValue 返回给 message</span>
            return this.value</span><span style="color: #000000;">
        }

    })

</span>