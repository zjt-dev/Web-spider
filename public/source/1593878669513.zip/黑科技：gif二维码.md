本篇文章是缘于在微博上看到了一的有意思的东西。由于腾讯与阿里的竞争关系，如果你是一个大V，在微博上发布微信的二维码会被屏蔽掉。于是有人发现了这样一个现象：人眼有视觉暂留效应，手机的摄像头由于捕捉影像的频率较低，也会有类似人眼的“视觉暂留”效应，利用这个原理，如果把一个二维码分为两个部分，放在一张gif图片的不同帧上，循环播放，用手机扫一扫这个“抽搐”的二维码，也是可以识别到的！但是这样的二维码，目前还不能被微博的技术检测到，所以不会被屏蔽。

请看示例：

 ![](https://images.cnblogs.com/cnblogs_com/lvdabao/507840/o_download%20(5).gif)

这样的gif二维码，是可以被微信扫一扫识别到的！不信你扫一下试试。以后可以在微博中发布这样的二维码了！

为了便于大家尝试，我写了一个小工具，上传二维码，自动生成这样的gif二维码，有兴趣的来试试吧~

访问地址：[http://idoube.com/proj/gifqrcode/](http://idoube.com/proj/gifqrcode/)

实现原理很简单，就是用了HTML5的fileReader API和canvas。关于生成gif，github上有一个库叫gif.js，很方便，我就拿来用了。有兴趣的可以前往：[https://github.com/jnordberg/gif.js](https://github.com/jnordberg/gif.js)

缺点是它用HTML5的worker来跑这个转化过程，所以你的浏览器必须支持worker，所以请使用chrome来访问。