 for、foreach终止循环
----------------

foreach 通过 throw   \*\*\*  抛出错误  通过 try {}catch(e){}接受错误 根据错误做出判断

![](https://images.cnblogs.com/OutliningIndicators/ContractedBlock.gif)![](https://images.cnblogs.com/OutliningIndicators/ExpandedBlockStart.gif)

 1 try{
 2                     list.forEach((i) => { 3                         if(!i.title){
 4                             throw 'BreakT'
 5                         }
 6                         if (i.option\_type == 0 || i.option\_type == 1) {
 7                             i.option.forEach(v => { 8                                 if (!v && v !== 0) {
 9                                     throw 'BreakV'; 10 } 11 }) 12 } 13 }) 14                 }catch(e){ 15 uni.showToast({ 16                         icon: 'none', 17                         title: e == 'BreakT' ? '您有题目未添加标题，请检查' :'您有选项未设置问题，请检查'
18 }) 19                     return false; 20                 }    

View Code

for循环直接 break