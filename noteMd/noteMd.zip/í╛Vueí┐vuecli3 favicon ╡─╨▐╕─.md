在vue.config.js中配置pwa，重跑下项目就行了 // 以下是pwa配置
 pwa: {
      iconPaths: {
        favicon32     : 'faviconfc.ico',
        favicon16     : 'faviconfc.ico',
        appleTouchIcon: 'faviconfc.ico',
        maskIcon      : 'faviconfc.ico',
        msTileImage   : 'faviconfc.ico' }
    },