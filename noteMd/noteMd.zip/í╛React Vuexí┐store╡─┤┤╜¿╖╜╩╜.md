React:
------

　 flux:  从events模块引入 emit on 方法

import EventEmitter from 'events' 合并对象
const Store \= Object.assign({},EventEmitter.prototype,{
   state:{}     
   getState:{} 
})

　　redux: 从redux引入createStore

import {createStore} from 'redux'
/\*redux内部有createStore方法\*/ import reducers from '...' const store \= createStore(reducers)
export default store

Vuex:
-----

import  Vue  from 'vue' import  Vuex from 'vuex' Vue.use(Vuex)

const Store \= new Vuex.Store()

export default  Store