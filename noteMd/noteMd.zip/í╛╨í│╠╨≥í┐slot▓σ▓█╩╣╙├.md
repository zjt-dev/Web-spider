自定义组件

<view class\="wrapper"\>
  <slot name\="myslot"\>slot\>
  <view\>这里是组件的内部节点view\>
  <slot\>slot\>
view\>

引用组件的页面模版

<view\>
  <my-component\>
    
     <view\>这里是插入到组件slot中的内容view\> 
     <view slot\="myslot"\>sdfdsfview\>
  my-component\>
view\>

注意的是需要在自定义组件的JS文件中写入：

options: {
    multipleSlots: true  //启用slot插槽
  },

否则 slot中的name不生效