中午出现这个问题，发现是JQuery版本的原因

使用jQuery1.9含1.9以下版本的jQ库是不会有问题的

使用jQuery1.9以上版本的话用prop代替attr

#### 关于attr和prop的区别

具有 true 和 false 两个属性的属性，如 checked, selected 或者 disabled 使用prop()，其他的使用 attr()，

[可以看下这里](https://blog.wenzhixin.net.cn/2013/05/24/jquery_attr_prop/)

#### 顺便说一下jQ控制radio选中的 方法

选中
$(this).find("input\[name='paytype'\]").prop("checked", "true")
反选
$(this).find("input\[name='paytype'\]").prop("checked", "false")