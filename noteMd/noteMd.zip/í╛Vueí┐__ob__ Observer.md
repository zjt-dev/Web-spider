### Vue中带有\_\_ob\_\_: Observer的数组,无法稳定的取到里边的值?

### 求解！！！

* * *

补充：

　　参考  [https://blog.csdn.net/qq\_37285177/article/details/78935831](https://blog.csdn.net/qq_37285177/article/details/78935831)

### ![](https://img2018.cnblogs.com/blog/1524685/201904/1524685-20190404095112647-1046966828.png)

![](https://img2018.cnblogs.com/blog/1524685/201904/1524685-20190404095314203-685080147.png)