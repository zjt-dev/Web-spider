 文字两端对齐
-------

 width: 80px;
    text-align: justify;
    text-align-last: justify;
    -moz-text-align-last: justify;
    text-align: justify;
    text-justify: distribute-all-lines;
    display: block; /\*兼容IE\*/

 ![](https://img2020.cnblogs.com/blog/1524685/202005/1524685-20200515172209830-1432698473.png)