 

<script\> $(document).ready(function () { var adv \= $(".homeImg")
        adv.click(function () {
            $(this).animate({
                height:'toggle',
                width:'toggle' })
        }) // 设置cookie
        function setCookie(name, value) { var Days \= 30; var exp \= new Date();
            exp.setTime(exp.getTime() + Days \* 24 \* 60 \* 60 \* 1000);
            document.cookie \= name + "\=" + escape(value) + ";expires=" + exp.toGMTString();//设置过期时间
        } // 获取cookie
        function getCookie(name) { var arr, reg \= new RegExp("(^| )" + name + "\=(\[^;\]\*)(;|$)"); if (arr \= document.cookie.match(reg)){ return unescape(arr\[2\]);
            }else{ return null;
            }
        } /\*判断网页是否是第一次浏览，如果第一次则，然后设置cookie值，否则把图片隐藏\*/
        if (getCookie('name')) {
            $('.homeImg').css('display', 'none')
        } else {
            setCookie('name','word')
            console.log(getCookie('name')) // $('homeImg').css('display','none')
 }

    }) script\>

### 关于cookie的使用，复习下

设置 cookie 值的函数
function setCookie(cname,cvalue,exdays)
{
  var d = new Date();
  d.setTime(d.getTime()+(exdays\*24\*60\*60\*1000));
  var expires = "expires="+d.toGMTString();
  document.cookie = cname + "=" + cvalue + "; " + expires;
}  
  
获取 cookie 值的函数
function getCookie(cname)
{
  var name = cname + "=";
  var ca = document.cookie.split(';');
  for(var i=0; i<ca.length; i++) 
  {
    var c = ca\[i\].trim();
    if (c.indexOf(name)==0) return c.substring(name.length,c.length);
  }
  return "";
}


检测 cookie 是否创建的函数

如果设置了 cookie，将显示一个问候信息。

如果没有设置 cookie，将会显示一个弹窗用于询问访问者的名字，并调用 setCookie 函数将访问者的名字存储 365 天：

function checkCookie()
{
  var username=getCookie("username");
  if (username!="")
  {
    alert("Welcome again " + username);
  }
  else 
  {
    username = prompt("Please enter your name:","");
    if (username!="" && username!=null)
    {
      setCookie("username",username,365);
    }
  }
}

### 深入了解cookie[https://www.cnblogs.com/zhuanzhuanfe/p/8010854.html](https://www.cnblogs.com/zhuanzhuanfe/p/8010854.html)