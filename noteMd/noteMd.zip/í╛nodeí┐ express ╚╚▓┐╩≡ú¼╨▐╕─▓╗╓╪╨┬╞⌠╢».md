安装 node-dev 插件

`cnpm install -g node-dev`

修改packge.json

    {
      "name": "serve",
      "version": "0.0.0",
      "private": true,
      "scripts": {
        "start": "nodemon ./bin/www",
        **"dev": "node-dev ./bin/www"**
      },
      "dependencies": {
        "cookie-parser": "~1.4.4",
        "debug": "~2.6.9",
        "express": "~4.16.1",
        "morgan": "~1.9.1"
      }
    }
    

执行 npm run dev